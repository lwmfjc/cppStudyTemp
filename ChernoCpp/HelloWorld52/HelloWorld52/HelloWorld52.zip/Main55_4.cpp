//#include <iostream> 
//
//#if 1
//
////#define LY_DEBUG 0
//#if LY_DEBUG == 1 //����ʹ��ֵ�ж�
////#ifdef LY_DEBUG
//#define LOG(x) std::cout << x << std::endl
//#elif defined(LY_RELEASE)
//#define LOG(x)
//#endif
//
//#endif
//
//int main()
//{
//
//	LOG("Hello");
//	std::cin.get();
//}