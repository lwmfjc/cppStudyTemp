//#include <iostream>  
//
//void HelloWorld()
//{
//	std::cout << "HelloWorld!" << std::endl;
//}
//
//
//int test(float a)
//{
//	std::cout << a << "!" << std::endl;
//	return 1;
//}
//
//int main()
//{
//	//function������->void (*function)()
//	auto function1 = &HelloWorld;
//	//&����ʡ�ԣ���Ϊ����ʽת��
//	auto function = HelloWorld;
//	//�൱��
//	void(*function2)() = HelloWorld;
//	int(*function3)(float) = test;
//
//	function();
//	(*function)();
//	function1();
//	(*function1)();
//	function2();
//	(*function2)();
//
//	function3(3.0);
//	std::cin.get();
//}