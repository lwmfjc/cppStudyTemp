//#include <iostream>  
//
//void HelloWorld()
//{
//	std::cout << "HelloWorld!" << std::endl;
//} 
//
//
//void HelloWorld(int a)
//{
//	std::cout << "HelloWorld!value: " << a << std::endl;
//}
//
//int main()
//{ 
//
//	//ʹ�ñ���
//	typedef void(*HelloWorldFunction)();
//	//��������ֵ
//	HelloWorldFunction function = HelloWorld;
//	function();
//
//	//ʹ�ñ���
//	typedef void(*HelloWorld1Function)(int);
//	//��������ֵ
//	HelloWorld1Function function1 = HelloWorld;
//	function1(3);
//
//
//	std::cin.get();
//}