#include <iostream>
#include <utility> 

#include "String.h"

struct ShaderProgramSource
{
	String VertexSource;
	String FragmentSource;
};

ShaderProgramSource ParseShader()
{
	//����vs��fs���ռ���ֵ��abc��def 
	String vs = "abc";
	String fs = "def";
	std::cout << "===1===" << std::endl;
	 
	//return  { vs,fs };
	return { std::move(vs), std::move(fs) };
}

int main()
{

	ShaderProgramSource sps = ParseShader();
	std::cout << "==2====" << std::endl;
	std::cout << sps.VertexSource << std::endl;
	std::cout << sps.FragmentSource << std::endl;
	std::cin.get();
}
/*
===1===
Copied String!abc
Copied String!def
==2====
abc
def

*/