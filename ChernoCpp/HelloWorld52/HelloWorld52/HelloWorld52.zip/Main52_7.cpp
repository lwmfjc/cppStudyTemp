//#include <iostream>
//#include <utility> 
//
//#include "String.h"
//
//
//std::pair<String,String> ParseShader()
//{
//	//����vs��fs���ռ���ֵ��abc��def 
//	String vs = "abc";
//	String fs = "def"; 
//
//	//std::make_pair ��һ����ֵ���ݣ�Pass by Value���ĺ�����
//	return  std::make_pair(vs,fs);
//}
//
//int main()
//{
//
//	std::pair<String, String> result = ParseShader(); 
//	std::cout << "======" << std::endl;
//	std::cout << std::get<0>(result) << std::endl;
//	std::cout << std::get<1>(result) << std::endl;
//	std::cout << result.first << std::endl;
//	std::cout << result.second << std::endl;
//	std::cin.get();
//}
///*
//Copied String!abc
//Copied String!def
//======
//abc
//def
//abc
//def
//
//*/