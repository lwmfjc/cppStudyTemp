//#include <iostream> 
//
//int main()
//{
//	auto x = 1;//int
//	auto y = 1.0;//double
//	int a = 5;
//	auto b = a;//int
//	auto c = y;//double
//	auto d = 3L;//long
//	auto e = 5.3f;//float
//	auto f = "aa";//const char* //�����ַ�ָ��
//	std::cout << x << std::endl;
//	std::cout << y << std::endl;
//	std::cout << a << std::endl;
//	std::cout << b << std::endl;
//	std::cout << c << std::endl;
//	std::cin.get();
//}