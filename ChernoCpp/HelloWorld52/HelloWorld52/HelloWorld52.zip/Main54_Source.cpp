//#include <iostream>
//#include <string>
//
//struct Vector3
//{
//	float x, y, z;
//	Vector3()
//		:x(10), y(11), z(12)
//	{
//
//	}
//};
//
//int main()
//{
//	//��ջ�Ϸ����ڴ�
//	int value1 = 1;
//	int value2 = 2;
//	int value3 = 3;
//	int value4 = 4;
//	int value5 = 5;
//	std::cout << &value1 << std::endl;
//	std::cout << &value2 << std::endl;
//	std::cout << &value3 << std::endl;
//	std::cout << &value4 << std::endl;
//	std::cout << &value5 << std::endl;
//
//	std::cin.get();
//}