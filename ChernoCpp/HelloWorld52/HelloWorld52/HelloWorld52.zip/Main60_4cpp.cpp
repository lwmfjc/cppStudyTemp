#include <iostream>  
#include <string>

namespace apple {
	namespace functions {
		void print(const char* text)
		{
			std::cout << text << std::endl;
		}
	}

}

namespace orange {
	void print(const char* text )
	{
		std::string temp = text;
		std::reverse(temp.begin(), temp.end());
		std::cout << text << std::endl;
	}
}

int main()
{
	{
		//����
		namespace a = apple::functions;
		a::print("ha");

		//using ָ����ܽС�������
		using namespace apple;
		using namespace functions;
		print("c");
	}
	//a::print("ha");//���뱨��
	//print("c");//���뱨��

	std::cin.get();
}