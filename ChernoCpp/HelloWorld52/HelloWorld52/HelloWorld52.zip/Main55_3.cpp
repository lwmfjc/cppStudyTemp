//#include <iostream>
//#include <string>
//
//#define LOG(x) std::cout << x << std::endl
//
//int main()
//{
//
//	LOG("Hello");
//	std::cin.get();
//}