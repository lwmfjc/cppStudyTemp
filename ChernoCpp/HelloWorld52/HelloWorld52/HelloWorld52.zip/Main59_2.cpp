//#include <iostream>
//#include <vector>  
//#include <algorithm>
//
//
//int main()
//{
//	std::vector<int> values = { 1,5,4,3,2,5 };
//
//	//it��һ�������� -> std::vector<int>::iterator
//	auto it = std::find_if(values.begin(), values.end(), [](int value) {return value > 3; });
//
//	std::cout << *it << std::endl;//5
//
//
//	std::cin.get();
//}