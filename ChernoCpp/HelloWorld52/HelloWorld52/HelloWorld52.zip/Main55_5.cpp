//#include <iostream>
//#include <string>
//
//# define MAIN int main() \
//{\
//\
//	std::cin.get();\
//}
//
//MAIN 