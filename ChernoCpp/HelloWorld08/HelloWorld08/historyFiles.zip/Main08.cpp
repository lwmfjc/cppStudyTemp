#include <iostream>

int main() {

	int variable = 8;
	std::cout << variable << std::endl;
	variable = 20;
	std::cout << variable << std::endl;
	//std::cin.get();


	short sVariable = 'A';
	//short cVariable=65;
	//��������65����'A'��ֵ����ӡ�����Ķ���65
	std::cout << sVariable << std::endl;


	long lVariable = 8;
	std::cout << "long�ֽ�" << sizeof(lVariable) << std::endl;


	float fVariable = 8.2f;
	std::cout << fVariable << std::endl;
	double dVariable = 20.3;
	std::cout << dVariable << std::endl;
	//std::cin.get();

	bool bVariable = true;
	std::cout << bVariable << std::endl;
	bVariable = false;
	std::cout << bVariable << std::endl;
	bVariable = 322;
	std::cout << bVariable << std::endl;

	std::cout << sizeof(lVariable) << std::endl;


	std::cin.get();

}