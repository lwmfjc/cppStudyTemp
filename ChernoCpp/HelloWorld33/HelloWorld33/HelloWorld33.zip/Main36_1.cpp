﻿#include <iostream>
#include <string>

static int s_Level = 12;
static int s_Speed = 2;

int main()
{

	if (s_Level > 5)
		s_Speed = 10;
	else
	{
		s_Speed = 5;
	}

	s_Speed = s_Level > 5 ? 10 : 5;
	//嵌套
	// 
	//s_Level > 5 && s_Level < 100 这个会先被连接在一起判断
	s_Speed = s_Level > 5 && s_Level < 100 ? s_Level > 10 ? 15 : 10 : 5;

	//如果>5的情况下，如果还>10，则15，如果不大于10则10；否则(不
	//>5)，则5
	s_Speed = s_Level > 5 ? s_Level > 10 ? 15 : 10 : 5;


	//方式1：这里没有多构造空对象其实和编译器有关，后面会说到
	std::string rank = s_Level > 10 ? "Master" : "Beginer";

	//方式2：这种声明方式，还会比上面额外多构造一个空字符串对象
	std::string otherRank;
	if (s_Level > 10)
		otherRank = "Master";
	else
		otherRank = "Beginer";

	std::cout << s_Speed << std::endl; //15

	std::cin.get();
}