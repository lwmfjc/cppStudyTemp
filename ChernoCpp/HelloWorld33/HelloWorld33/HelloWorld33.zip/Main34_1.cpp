﻿#include <iostream>
#include <string>

class Entity
{
private:
	std::string m_Name;

	//允许标记为const的方法修改该变量
	mutable int m_DebugCount = 0;

public:

	//1.如果是 const std::string，则返回的是一个副本
	//返回一个引用
	//2.最后的const表示该函数内部不允许修改类的非static成员变量
	const std::string& GetName() const
	{
		//m_Name = "a";//非法
		m_DebugCount++;//编译通过

		//由于返回的是引用，所以这里返回了成员变
		//量 m_Name 的一个“地址”或“别名”
		return m_Name;
	}

	void MyTest()
	{

	}
};

int main()
{
	const Entity e;
	e.GetName();//调用const方法
	//e.MyTest();//不允许调用非const方法


	Entity e1;
	e1.GetName();//调用const方法
	e1.MyTest();//调用非const方法 

	std::cin.get();
}