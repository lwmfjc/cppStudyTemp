#include <iostream>  
#include <string>

class Entity
{
public:

	//constructor-���캯��
	Entity()
	{
		std::cout << "Created Entity!" << std::endl;
	}


	//destructor-��������
	~Entity()
	{
		std::cout << "Destroyed Entity!" << std::endl;
	}

};

class ScopedPtr
{
private:
	Entity* m_Ptr;
public:
	ScopedPtr(Entity* ptr)
		:m_Ptr(ptr)
	{

	}

	~ScopedPtr()
	{
		delete m_Ptr;
	}
};

int main()
{
	std::cout << "start--" << std::endl;
	{
		//�����вι��캯��,��ʽת��
		ScopedPtr e = new Entity();
		//Entity* e = new Entity();

	}
	std::cout << "end--" << std::endl;
	std::cin.get();
}
/*
start--
Created Entity!
Destroyed Entity!
end--
*/