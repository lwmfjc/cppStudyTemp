﻿//#include <iostream>  
//#include <string>
//
//class Entity
//{
//public:
//
//	//constructor-构造函数
//	Entity()
//	{
//		std::cout << "Created Entity!" << std::endl;
//	}
//
//
//	//destructor-析构函数
//	~Entity()
//	{
//		std::cout << "Destroyed Entity!" << std::endl;
//	}
//
//};
//
//int main()
//{
//	//std::cout << "start--" << std::endl;
//	//{
//	//	Entity e;
//	//}
//	//std::cout << "end--" << std::endl;
//
//	std::cout << "start--" << std::endl;
//	{
//		Entity* e=new Entity();
//	}
//	std::cout << "end--" << std::endl;
//	std::cin.get();
//}