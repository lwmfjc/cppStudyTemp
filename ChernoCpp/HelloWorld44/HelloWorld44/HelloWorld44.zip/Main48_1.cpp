//#include <iostream>
//
//void Function()
//{
//	int i = 0;
//	i++;
//	std::cout << i << std::endl;
//}
//
//void Function1()
//{
//	static int i = 0;
//	i++;
//	std::cout << i << std::endl;
//}
//
//void Function2()
//{
//	static int i = 2;
//	i+=2;
//	std::cout << i << std::endl;
//}
//int main()
//{
//	Function();
//	Function();
//	Function();
//	/*
//	1
//	1
//	1
//	*/
//	Function1();
//	Function2();
//	Function1();
//	Function2();
//	Function1();
//	Function2();
//	/*��ͬ������ͬ����̬��������Ӱ��
//	1
//	2
//	2
//	4
//	3
//	6
//	*/
//	std::cin.get();
//} 